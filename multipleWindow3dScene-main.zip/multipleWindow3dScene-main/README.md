## 3d scene spanning multiple windows using three.js and localStorage

A simple example showing how to setup a 3d scene across windows on the same origin using three.js and localStorage. Code should be self explanatory

follow me on twitter at [@_nonfigurativ_](https://twitter.com/_nonfigurativ_) for more stuff like this